<?php /* Smarty version 2.6.11, created on 2020-04-02 01:42:01
         compiled from themes/RacerX/tpls/header.tpl */ ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "themes/RacerX/tpls/_head.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<body class="yui-skin-sam">
    <a name="top"></a>
    <div style="position:fixed;top:0;left:0;width:1px;height:1px;z-index:21;"></div>
    <div class="clear"></div>

<div id="main">
    <div id="content">
        <?php if ($this->_tpl_vars['use_table_container']): ?>
        <table style="width:100%" id="contentTable"><tr><td>
        <?php endif; ?>