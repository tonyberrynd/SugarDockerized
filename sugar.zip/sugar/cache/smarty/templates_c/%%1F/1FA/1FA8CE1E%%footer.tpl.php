<?php /* Smarty version 2.6.11, created on 2020-04-02 01:42:02
         compiled from modules/Calendar/tpls/footer.tpl */ ?>
<div class='monthFooter'>
	<div style='float: left;'><?php echo $this->_tpl_vars['previous']; ?>
</div><div style='float: right;'><?php echo $this->_tpl_vars['next']; ?>
</div>
</div>
<br style='clear:both;'>