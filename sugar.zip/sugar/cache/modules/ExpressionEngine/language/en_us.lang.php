<?php
// created: 2020-04-04 15:47:26
$mod_strings = array (
  'LBL_MODULE_NAME' => 'Expression Engine',
  'LBL_MODULE_NAME_SINGULAR' => 'Expression Engine',
  'func_descriptions' => 
  array (
  ),
  'LBL_PREVIOUS' => 'Previous',
  'LBL_NEXT' => 'Next',
  'LBL_EXPAND' => 'Expand',
);