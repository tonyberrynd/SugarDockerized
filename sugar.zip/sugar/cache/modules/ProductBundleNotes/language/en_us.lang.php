<?php
// created: 2020-04-03 20:12:46
$mod_strings = array (
  'LBL_BUNDLE_NOTE_POSITION' => 'Product Bundle Position',
  'LBL_PRODUCT_BUNDLE_NOTES_QUOTE_DATA_LIST' => 'Product Bundle Notes Quote Data List',
);